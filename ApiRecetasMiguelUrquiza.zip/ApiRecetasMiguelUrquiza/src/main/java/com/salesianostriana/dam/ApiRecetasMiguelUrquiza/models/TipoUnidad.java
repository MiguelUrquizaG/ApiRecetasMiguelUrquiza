package com.salesianostriana.dam.ApiRecetasMiguelUrquiza.models;

public enum TipoUnidad {
    GRAMOS,
    LITROS,
    KILOS
}
