package com.salesianostriana.dam.ApiRecetasMiguelUrquiza.errors.confict;

public class IngredienteRecetaConflictException extends EntityConflict {
    public IngredienteRecetaConflictException(String message) {
        super(message);
    }
}
