package com.salesianostriana.dam.ApiRecetasMiguelUrquiza.errors.badRequest;

public class CategoriaNoValidaException extends EntityBadRequestException {
    public CategoriaNoValidaException(String message) {
        super(message);
    }

}
