package com.salesianostriana.dam.ApiRecetasMiguelUrquiza;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiRecetasMiguelUrquizaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiRecetasMiguelUrquizaApplication.class, args);
	}

}
