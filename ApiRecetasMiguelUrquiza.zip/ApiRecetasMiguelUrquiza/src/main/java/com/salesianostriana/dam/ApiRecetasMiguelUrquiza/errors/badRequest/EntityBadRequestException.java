package com.salesianostriana.dam.ApiRecetasMiguelUrquiza.errors.badRequest;

public class EntityBadRequestException extends RuntimeException {
    public EntityBadRequestException(String message) {
        super(message);
    }
}
