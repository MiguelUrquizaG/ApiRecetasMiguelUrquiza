package com.salesianostriana.dam.ApiRecetasMiguelUrquiza.models;

public enum Dificultad {
    FACIL,
    MEDIA,
    DIFICIL
}
