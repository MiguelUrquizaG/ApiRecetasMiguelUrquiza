package com.salesianostriana.dam.ApiRecetasMiguelUrquiza.errors.confict;

public class IngredienteCreadoException extends EntityConflict {
    public IngredienteCreadoException(String message) {
        super(message);
    }
}
