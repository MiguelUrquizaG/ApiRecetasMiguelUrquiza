package com.salesianostriana.dam.ApiRecetasMiguelUrquiza.errors.badRequest;

public class IngredienteNoValidoException extends EntityBadRequestException {
    public IngredienteNoValidoException(String message) {
        super(message);
    }
}
