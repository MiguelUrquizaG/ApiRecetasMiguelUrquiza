package com.salesianostriana.dam.ApiRecetasMiguelUrquiza;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiRecetasMiguelUrquizaApplicationTests {

	@Test
	void contextLoads() {
	}

}
